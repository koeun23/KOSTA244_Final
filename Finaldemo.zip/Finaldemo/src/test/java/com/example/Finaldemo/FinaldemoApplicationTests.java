package com.example.Finaldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinaldemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
